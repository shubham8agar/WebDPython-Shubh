example code for chapter 5

README.txt		this file

carexample.py	small example applications
carexample2.py

booksweb.py		the toplevel application.
				run as:   python booksweb.py
				point browser to:  http://127.0.0.1:8080
				contains default  admin/admin

booksdb.py		the object aabstraction layer

entity.py		the entity module, defines Entity class
relation.py		the relation module, defines Realtion class

books.css		style sheet
basepage.html	base page as used by the application. Points to google CDN
booksweb.js		jQuery/jQueryUI functionality for the booksweb.py application

logon.py		files used to logon
logondb.py		...
logon.css		...
