Contents of the directory "Chapter 2"
=====================================

README.txt			this file

Code samples refered to in the main text
----------------------------------------
nocontent.py		serves a simple page with just some text

unitconvertor.py	serves a unitconvertor
unitconvertor.js	the actual Javascript implementation of the unitconvertor

spreadsheet.py		serves a spreadsheet
spreadsheet.js		the actual Javascript implementation of the spreadsheet

static				directory containing external Javascript libraries, plugins and stylesheets

Example implementations for some of the Have a go Hero sections
---------------------------------------------------------------
zebra.html			a html page with a table with alternating background colors.

unitconvertor2.py	serves extended unitconvertor
unitconvertor2.js	the actual Javascript implementation of the extended unitconvertor

spreadsheet2.py		serves an extended spreadsheet
spreadsheet2.js		the actual Javascript implementation of the extended spreadsheet

===============
All examples may be run from the commandline, typically just

python example.py

and the web application served may then be accessed by pointing your browser to

http://localhost:8080/

Refer to the book on how to interact with the specific web applications.
