crmcontact.py		example application show list of entities

crmcontactedit.py	example application showing how to edit entities

fruit.py			example application showing picklists

crm1.py				first stab a simple CRM application

entity				entity/relation framework packed in one module

browse.py			module to browse a list of entities
display.py			module to display, edit or add an entity

logon.py			modules that provide user authentication
logondb.py

basepage.html		basix HTML structure of applications
base.css			corresponding style sheet