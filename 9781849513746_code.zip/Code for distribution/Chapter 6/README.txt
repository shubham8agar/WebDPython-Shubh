example code for chapter 6

README.txt		this file

carexample.py	small example applications
carexample2.py

wikiweb.py		the toplevel application.
				run as:   python wikiweb.py
				point browser to:  http://127.0.0.1:8080
				contains default  admin/admin

wikidb.py		the object aabstraction layer
wiki.py			domain specific functionality

entity.py		the entity module, defines Entity class
relation.py		the relation module, defines Realtion class

wiki.css		style sheet
basepage.html	base page as used by the application. Points to google CDN
wikiweb.js		jQuery/jQueryUI functionality for the wikiweb.py application

logon.py		files used to logon
logondb.py		...
logon.css		...
