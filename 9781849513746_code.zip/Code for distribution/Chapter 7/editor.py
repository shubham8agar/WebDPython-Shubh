class Editor():
	def __init__(self, entity,add=False):
		pass