testentity.py			example app, shows validation

metaclassexample.py		using metaclasses to check correct inheritance

entity.py				refactored implementations of our entity/relation framework
relation.py

logon.py				used for user authentication
logondb.py		

browse.py				sample application to show browsing lists of entities

books2.py				books application based on refactored entity/relation framework
basepage.html			HTML markup to structure the data

sample applications may be run as follows:

python books2.py
and then interact with it by pointing your browser to http://localhost:8080

If asked for a username password, the defaults are admin/admin
